﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService.Model
{
    public  class DBConstants
    {
        public static string Product = "Product";
        public static string Buyer = "Buyer";
        

        //enum Tables
        //{
        //    Product,
        //    Buyer

        //}
    }
}
