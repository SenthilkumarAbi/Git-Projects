﻿using BuyerService.Model;
using BuyerService.Processor.Interfaces;
using BuyerService.Repositories;
using BuyerService.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService.Processor
{
    public class BuyerProcessor : IBuyerProcessor
    {
        public IBuyerRepository _buyerRepository;
        public BuyerProcessor(IBuyerRepository buyerRepository)
        {
            this._buyerRepository = buyerRepository;
        }

        public Buyer PlaceBid(Buyer buyer)
        {
            return this._buyerRepository.PlaceBid(buyer);
        }

        public  Buyer updateBid(Buyer buyerinfo)
        {
            return this._buyerRepository.updateBid(buyerinfo);
        }
    }
}
