﻿using BuyerService.Model;
using BuyerService.Repositories.Interfaces;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService.Repositories
{
    public class BuyerRepository : IBuyerRepository
    {
        private readonly AppSetting _appSettingAccessor;
        private readonly MongoDBConfig _mongoDBConfig;
        private IMongoDatabase _iMongoDBDatabase;
        public BuyerRepository(IOptions<AppSetting> appSettingAccessor, IOptions<MongoDBConfig> mongoDBAccesssor)
        {
            _appSettingAccessor = appSettingAccessor.Value;
            _mongoDBConfig = mongoDBAccesssor.Value;
            var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
            _iMongoDBDatabase = client.GetDatabase(_appSettingAccessor.DatabaseName);
        }

        public List<Buyer> getAllBuyers()
        {
            return _iMongoDBDatabase.GetCollection<Buyer>(DBConstants.Buyer).Find(new BsonDocument()).ToList();
            
        }
        public Buyer PlaceBid(Buyer buyerinfo)
        {

            var _buyers = _iMongoDBDatabase.GetCollection<Buyer>(DBConstants.Buyer);
            
            Buyer _buyer = new Buyer()
            {
                FirstName = buyerinfo.FirstName,
                LastName = buyerinfo.LastName,
                Address = buyerinfo.Address,
                State = buyerinfo.State,
                Pin = buyerinfo.Pin,
                Phone = buyerinfo.Phone,
                Email = buyerinfo.Email,
                ProductName = buyerinfo.ProductName,
                ProductId = buyerinfo.ProductId,
                BidAmount = buyerinfo.BidAmount

            };

            _buyers.InsertOne(_buyer);
            return _buyer;

        }

        private Buyer GetBuyerByProductName()
        {
            var _buyers = _iMongoDBDatabase.GetCollection<Buyer>(DBConstants.Buyer);
            Buyer buyer = _buyers.Find(new BsonDocument()).SortByDescending(x => x._id).FirstOrDefault();
            var results = _iMongoDBDatabase.GetCollection<Buyer>(DBConstants.Buyer).Find(new BsonDocument()).ToList();
            var checl = results.Where(x => x._id == buyer._id).FirstOrDefault();

            return checl;
        }

        public Buyer updateBid( Buyer buyerinfo)//, int buyerProductId, string buyerEmail, double newBidAmount )
        {
            //{productId}/{buyerEmailld}/{newBidAmount}
            var _buyers = _iMongoDBDatabase.GetCollection<Buyer>(DBConstants.Buyer);

            var filter = Builders<Buyer>.Filter.Eq(x=> x.ProductId , buyerinfo.ProductId );
            filter &= (Builders<Buyer>.Filter.Eq(x => x.Email, buyerinfo.Email));
            var updateDef = Builders<Buyer>.Update.Set("BidAmount", buyerinfo.BidAmount);
            var result = _buyers.UpdateOne(filter, updateDef);

            return buyerinfo;
        }
    }
}
