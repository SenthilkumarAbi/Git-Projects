﻿using BuyerService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService.Repositories.Interfaces
{
    public interface IBuyerRepository
    {
        Buyer updateBid(Buyer buyerinfo);
        Buyer PlaceBid(Buyer buyerinfo);
        List<Buyer> getAllBuyers();


    }
}
