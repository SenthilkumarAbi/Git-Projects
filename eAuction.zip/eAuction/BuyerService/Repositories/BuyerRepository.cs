﻿using BuyerService.Model;
using BuyerService.Repositories.Interfaces;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService.Repositories
{
    public class BuyerRepository : IBuyerRepository
    {
        private readonly AppSetting _appSettingAccessor;
        private readonly MongoDBConfig _mongoDBConfig;

        public BuyerRepository(IOptions<AppSetting> appSettingAccessor, IOptions<MongoDBConfig> mongoDBAccesssor)
        {
            _appSettingAccessor = appSettingAccessor.Value;
            _mongoDBConfig = mongoDBAccesssor.Value;
        }

        public int PlaceBid(Buyer placeBid)
        {
            var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
            var database = client.GetDatabase(_appSettingAccessor.DatabaseName);
            //var client = new MongoClient(_mongoDBConfig.ConnectionString);
            //var database = client.GetDatabase(_mongoDBConfig.Database);
            var products = database.GetCollection<Product>("Product");
          //  List<Product> lstProducts = products.Find(game => true).ToList();
            //using(MongoClient client = new MongoClient(_appSettingAccessor.DatabaseConnectionString))
            //{

            //}
            Product newpdt = new Product()
            {
              //  _id =  Guid.NewGuid(),
                productId = 2,
                productName = "Proudct 5",
                shortDescription = "Product Short Description 5",
                detailedDescription = "Product Detailed Description 5",
                category = "Painting",
                startingPrice = 99.99,
                bidEndDate = "12-18-2022"
            };
            //Product newGame = new Product { productId:1,
            //    productName: "Proudct 1",
            //    shortDescription: "Product Short Description 1",
            //    detailedDescription: "Product Detailed Description 1",
            //    category: "Painting",
            //    startingPrice: 99.99,
            //    bidEndDate: "12-18-2021"

            products.InsertOne(newpdt);
            products = database.GetCollection<Product>("Product");
            List<Product> lstProducts = products.Find(x => 1==1).ToList();
            return 0;

        }
    }
}
