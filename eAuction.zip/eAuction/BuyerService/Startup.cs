using BuyerService.Model;
using BuyerService.Processor;
using BuyerService.Processor.Interfaces;
using BuyerService.Repositories;
using BuyerService.Repositories.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<IConfigurationRoot>(Configuration);
            services.Configure<AppSetting>(options =>
            {
                options.DatabaseConnectionString = Configuration.GetConnectionString("MongoDBConnectionString");
                options.DatabaseName = Configuration.GetValue<string>("DatabaseName", "DatabaseName");
            });

            services.Configure<MongoDBConfig>(options =>
            {
                options.Database = Configuration.GetSection("MongoDBConfig"). GetValue<string>("Database", "DatabaseName");
                options.User = Configuration.GetSection("MongoDBConfig").GetValue<string>("User", "DatabaseName");
                options.Host = Configuration.GetSection("MongoDBConfig").GetValue<string>("Host", "DatabaseName");
                options.Port = Configuration.GetSection("MongoDBConfig").GetValue<int>("Port", 5002);
                options.Password = Configuration.GetSection("MongoDBConfig").GetValue<string>("Password", "DatabaseName");
            });
            services.AddControllers();
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "Buyer Service info",
                    Version = "v2",
                    Description = "Buyer micro service",
                });
            });
            services.AddScoped<IBuyerRepository, BuyerRepository>();
            services.AddScoped<IBuyerProcessor, BuyerProcessor>();
            //services.AddSingleton<IMongoClient, MongoClient>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();
            app.UseSwagger();
            app.UseSwaggerUI(options => options.SwaggerEndpoint("/swagger/v2/swagger.json", "Buyer Service info"));

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
