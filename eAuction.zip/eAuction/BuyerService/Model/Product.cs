﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuyerService.Model
{
    public class Product
    {
//        Product Id
//ProductName(Notnull, Allow(5,30))
//ShortDescription
//DetailedDescription
//Category(Painting, Sculptor, Ornament)
//StartingPrice(Number)
//BidEndDate(Should be greater than > CurrentDate)


        [BsonId] 
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public int productId { get; set; }
        public string productName { get; set; }
        public string shortDescription { get; set; }
        public string detailedDescription { get; set; }
        public string category { get; set; }
        public double startingPrice { get; set; }
        public string bidEndDate { get; set; }
    }
}
