﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace WorkwithThreads
{
    class TickTock
    {
        public void Tick()
        {
            lock (this)
            {
                
                for (int i = 0; i < 5; i++)
                {
                    Thread.Sleep(1000);
                    Console.Write("Tick ");
                    //Sending signal to waiting threads
                    Monitor.Pulse(this);
                    //release lock on current object
                    Monitor.Wait(this); //allow to execute tock method
                }
            }
        }
        public void Tock()
        {
            lock (this)
            {
                
                for (int i = 0; i <5; i++)
                {
                    Thread.Sleep(1000);
                    Console.WriteLine("Tock");
                    //Sending signal to waitign threads
                    Monitor.Pulse(this);
                    //release lock on current object
                    Monitor.Wait(this); //allow to execute tick method
                }
            }
        }
        static void Main()
        {
            TickTock _obj = new TickTock();
            Thread t1 = new Thread(_obj.Tick);
            Thread t2 = new Thread(_obj.Tock);
            t1.Start();
            t2.Start();
            Console.Read();
        }
    }
}
