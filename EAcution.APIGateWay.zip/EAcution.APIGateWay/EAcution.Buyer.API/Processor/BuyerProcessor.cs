﻿using EAcution.Buyer.API.Processor.Interfaces;
using EAcution.Buyer.API.Repositories.Interfaces;
using EAcution.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Model = EAcution.Models;
namespace EAcution.Buyer.API.Processor
{
    public class BuyerProcessor : IBuyerProcessor
    {
        private readonly ILogger<BuyerProcessor> logger;
        public IBuyerRepository _buyerRepository;
        public BuyerProcessor(ILogger<BuyerProcessor> _logger,IBuyerRepository buyerRepository)
        {
            this.logger = _logger;
            this._buyerRepository = buyerRepository;
        }
        public List<Model.Buyer> getAllBuyers()
        {
            logger.LogInformation(nameof(BuyerProcessor) + " Method " + nameof(getAllBuyers));
            return this._buyerRepository.getAllBuyers();
        }
        public Model.Buyer PlaceBid(Model.Buyer buyer)
        {
            logger.LogInformation(nameof(BuyerProcessor) + " Method " + nameof(PlaceBid));
            return this._buyerRepository.PlaceBid(buyer);
        }

        public Model.Buyer updateBid(Model.Buyer buyerinfo)
        {
            logger.LogInformation(nameof(BuyerProcessor) + " Method " + nameof(updateBid));
            return this._buyerRepository.updateBid(buyerinfo);
        }
        public string DeleteBuyers(string productId)
        {
            logger.LogInformation(nameof(BuyerProcessor) + " Method " + nameof(DeleteBuyers));
            return this._buyerRepository.DeleteBuyers(productId);
        }
    }
}
