﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EAcution.Models;
using Model = EAcution.Models;
namespace EAcution.Buyer.API.Processor.Interfaces
{
    public interface IBuyerProcessor
    {
        Model.Buyer PlaceBid(Model.Buyer product);
        Model.Buyer updateBid(Model.Buyer buyerinfo);
        string DeleteBuyers(string productId);
        List<Model.Buyer> getAllBuyers();
    }
}
