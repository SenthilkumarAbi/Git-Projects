﻿using EAcution.Buyer.API.Processor.Interfaces;
using EAuction.Common.Utility.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Model = EAcution.Models;
namespace EAcution.Buyer.API.Controllers
{
    [ApiController]
    [Route("api/v1/Buyer")]
    public class BuyerController : ControllerBase
    {
        public IBuyerProcessor _buyerProcessor;
        public IUtility _utility;
        public IConfiguration _configuration;
        private readonly ILogger<BuyerController> logger;

        public BuyerController(IBuyerProcessor buyerProcessor, IUtility utility,IConfiguration configuration, ILogger<BuyerController> _logger)
        {
            this._buyerProcessor = buyerProcessor;
            this._utility = utility;
            this._configuration = configuration;
            this.logger = _logger;
        }
        [HttpGet]
        public string Get()
        {
            logger.LogInformation(nameof(BuyerController) + " Method start" + nameof(Get));

            return "Buyer";
        }
        [HttpGet]
        [Route("GetAllBuyer")]
        public List<Model.Buyer> getAllBuyers()
        {
            logger.LogInformation(nameof(BuyerController) + " Method start" + nameof(getAllBuyers));
            try
            {
                return _buyerProcessor.getAllBuyers();
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                throw;
            }
            finally
            {
                logger.LogInformation("Ended" + nameof(getAllBuyers));
            }

        }
        [HttpPost]
        [Route("PlaceBid")]
        public async Task<string> PlaceBid([FromBody] Model.Buyer buyer)
        {
            logger.LogInformation(nameof(BuyerController) + " Method start" + nameof(PlaceBid));
            try
            {
                string msg = string.Empty;
                List<Model.Buyer> lstBuyers = _buyerProcessor.getAllBuyers();
                Model.Buyer _buyer = lstBuyers.Find(x => x.Email.Equals(buyer.Email) && x.ProductName.Equals(buyer.ProductName));
                if (_buyer == null)
                {
                    string apiUrl = _configuration.GetValue<string>("ApiGateWaySettings:URL").ToString();
                    double timeout = _configuration.GetValue<double>("ApiGateWaySettings:TimeOut");
                    string getAllProduct = _configuration.GetValue<string>("ApiGateWaySettings:SellerMicroService:GetAllProduct").ToString();
                    HttpClient httpClient = _utility.HttpRequstHeader(apiUrl, timeout);
                    using (var response = await httpClient.GetAsync(getAllProduct))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        List<Model.Product> lstProduct = JsonConvert.DeserializeObject<List<Model.Product>>(apiResponse);
                        Model.Product product = lstProduct.Find(x => x.ProductName.Equals(buyer.ProductName));
                        if (product != null)
                        {
                            DateTime todayDate = DateTime.Now;
                            string[] formats = { "MM-dd-yyyy" };
                            DateTime bidDate = DateTime.ParseExact(product.BidEndDate, formats, new CultureInfo("en-US"), DateTimeStyles.None);
                            if (bidDate >= todayDate)
                            {
                                buyer.ProductId = product._id;
                                this._buyerProcessor.PlaceBid(buyer);
                                msg = "Your Bid Placed successfully.";
                            }
                            else
                            {
                                msg = "Sorry BidDate is ended.Could not be place.";
                            }
                        }
                        else
                        {
                            msg = "Given product is not exists.";
                        }
                    }
                }
                else
                {
                    msg = "More than one Bid cannot be placed for the same product.";
                }
                return msg;
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                throw;
            }
            finally
            {
                logger.LogInformation("Ended" + nameof(PlaceBid));
            }
            
        }
        [HttpPut]
        [Route("UpdateBid/{productName}/{email}/{newBidAmount}")]
        public async Task<Model.Buyer> updateBid(string productName, string email, double newBidAmount)
        {
            logger.LogInformation(nameof(BuyerController) + " Method start" + nameof(updateBid));
            try
            {
                Model.Buyer _buyer = new Model.Buyer();
                _buyer.Email = email;
                _buyer.BidAmount = newBidAmount;
                string apiUrl = _configuration.GetValue<string>("ApiGateWaySettings:URL").ToString();
                double timeout = _configuration.GetValue<double>("ApiGateWaySettings:TimeOut");
                string getAllProduct = _configuration.GetValue<string>("ApiGateWaySettings:SellerMicroService:GetAllProduct").ToString();
                HttpClient httpClient = _utility.HttpRequstHeader(apiUrl, timeout);
                using (var response = await httpClient.GetAsync(getAllProduct))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    List<Model.Product> lstProduct = JsonConvert.DeserializeObject<List<Model.Product>>(apiResponse);
                    Model.Product product = lstProduct.Find(x => x.ProductName.Equals(productName));
                    if (product != null)
                    {
                        _buyer.ProductId = product._id;
                    }
                }
                return this._buyerProcessor.updateBid(_buyer);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);
                throw;
            }
            finally
            {
                logger.LogInformation("Ended" + nameof(updateBid));
            }
            
        }
        [HttpDelete]
        [Route("DeleteBid/{productId}")]
        public string deleteBid(string productId)
        {
            logger.LogInformation(nameof(BuyerController) + " Method start" + nameof(deleteBid));
            try
            {
                return this._buyerProcessor.DeleteBuyers(productId);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, ex.Message);

                throw;
            }
            finally
            {
                logger.LogInformation("Ended" + nameof(deleteBid));
            }
            
        }
    }
}
