﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Model = EAcution.Models;
namespace EAcution.Buyer.API.Repositories.Interfaces
{
    public interface IBuyerRepository
    {
        Model.Buyer updateBid(Model.Buyer buyerinfo);
        Model.Buyer PlaceBid(Model.Buyer buyerinfo);
        List<Model.Buyer> getAllBuyers();
        string DeleteBuyers(string productId);

    }
}
