﻿using EAcution.Buyer.API.Repositories.Interfaces;
using Model=EAcution.Models;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace EAcution.Buyer.API.Repositories
{
    public class BuyerRepository : IBuyerRepository
    {
        private readonly ILogger<BuyerRepository> logger;
        private readonly Model.AppSetting _appSettingAccessor;
        private IMongoDatabase _iMongoDBDatabase;
        public BuyerRepository(ILogger<BuyerRepository> _logger, IOptions<Model.AppSetting> appSettingAccessor)
        {
            this.logger = _logger;
            _appSettingAccessor = appSettingAccessor.Value;
            var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
            _iMongoDBDatabase = client.GetDatabase(_appSettingAccessor.DatabaseName);
        }

        public List<Model.Buyer> getAllBuyers()
        {
            logger.LogInformation("Method start" + nameof(getAllBuyers));
            return _iMongoDBDatabase.GetCollection<Model.Buyer>(Model.DBConstants.Buyer).Find(new BsonDocument()).ToList();
            
        }
        public Model.Buyer PlaceBid(Model.Buyer buyerinfo)
        {
            this.logger.LogInformation("Method start" + nameof(PlaceBid));
            var _buyers = _iMongoDBDatabase.GetCollection<Model.Buyer>(Model.DBConstants.Buyer);
            Model.Buyer _buyer = new Model.Buyer()
            {
                FirstName = buyerinfo.FirstName,
                LastName = buyerinfo.LastName,
                Address = buyerinfo.Address,
                State = buyerinfo.State,
                Pin = buyerinfo.Pin,
                Phone = buyerinfo.Phone,
                Email = buyerinfo.Email,
                ProductName = buyerinfo.ProductName,
                ProductId = buyerinfo.ProductId,
                BidAmount = buyerinfo.BidAmount
            };
            _buyers.InsertOne(_buyer);
            this.logger.LogInformation("Method end" + nameof(PlaceBid));
            return _buyer;
        }
        public Model.Buyer updateBid(Model.Buyer buyerinfo)
        {
            this.logger.LogInformation("Method start" + nameof(updateBid));
            var _buyers = _iMongoDBDatabase.GetCollection<Model.Buyer>(Model.DBConstants.Buyer);
            var filter = Builders<Model.Buyer>.Filter.Eq(x=> x.ProductId , buyerinfo.ProductId );
            filter &= (Builders<Model.Buyer>.Filter.Eq(x => x.Email, buyerinfo.Email));
            var updateDef = Builders<Model.Buyer>.Update.Set("BidAmount", buyerinfo.BidAmount);
            var result = _buyers.UpdateOne(filter, updateDef);
            this.logger.LogInformation("Method end" + nameof(updateBid));
            return buyerinfo;
        }
        public string DeleteBuyers(string productId)
        {
            this.logger.LogInformation("Method start" + nameof(DeleteBuyers));
            var _filterBuyer = Builders<Model.Buyer>.Filter.Eq("ProductId", productId);
            var _buyers = _iMongoDBDatabase.GetCollection<Model.Buyer>(Model.DBConstants.Buyer);
            _buyers.DeleteMany(_filterBuyer);
            this.logger.LogInformation("Method end" + nameof(DeleteBuyers));
            return "success";
        }
    }
}
