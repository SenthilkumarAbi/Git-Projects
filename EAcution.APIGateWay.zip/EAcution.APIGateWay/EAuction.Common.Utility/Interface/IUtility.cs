﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace EAuction.Common.Utility.Interfaces
{
    public interface IUtility
    {
        HttpClient HttpRequstHeader(string uriPath, double timeout);
    }
}
