﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EAcution.Models;
using Model = EAcution.Models;
namespace EAcution.Seller.API.Processor.Interfaces
{
    public interface ISellerProcessor
    {
        Model.Seller InsertSeller(Model.Seller product);
        List<Model.Product> GetAllProduct();
        Model.Product InsertProduct(Model.Product product);
        string DeleteProduct(string productid);
    }
}
