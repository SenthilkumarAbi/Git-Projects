﻿using EAcution.Seller.API.Processor.Interfaces;
using EAcution.Seller.API.Repositories.Interfaces;
using EAcution.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Model = EAcution.Models;
using Microsoft.Extensions.Logging;

namespace EAcution.Seller.API.Processor
{
    public class SellerProcessor : ISellerProcessor
    {
        public ISellerRepository _sellerRepository;
        private readonly ILogger<SellerProcessor> logger;
        public SellerProcessor(ISellerRepository sellerRepository, ILogger<SellerProcessor> _logger)
        {
            this.logger = _logger;
            this._sellerRepository = sellerRepository;
        }
        public string DeleteProduct(string productid)
        {
            logger.LogInformation(nameof(SellerProcessor) + " Method " + nameof(DeleteProduct));
            return _sellerRepository.DeleteProduct(productid);
        }
        public List<Product> GetAllProduct()
        {
            logger.LogInformation(nameof(SellerProcessor) + " Method " + nameof(GetAllProduct));
            return _sellerRepository.GetAllProduct();
        }
        public Product InsertProduct(Product product)
        {
            logger.LogInformation(nameof(SellerProcessor) + " Method " + nameof(InsertProduct));
            return _sellerRepository.InsertProduct(product);
        }
        public Model.Seller InsertSeller(Model.Seller seller)
        {
            logger.LogInformation(nameof(SellerProcessor) + " Method " + nameof(InsertSeller));
            return _sellerRepository.InsertSeller(seller);
        }
    }
}
