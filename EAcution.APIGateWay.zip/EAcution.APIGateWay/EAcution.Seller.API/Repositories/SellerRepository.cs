﻿using EAcution.Seller.API.Repositories.Interfaces;
using Model=EAcution.Models;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EAcution.Models;
using Microsoft.Extensions.Logging;

namespace EAcution.Seller.API.Repositories
{
    public class SellerRepository : ISellerRepository
    {
        private readonly ILogger<SellerRepository> logger;
        private readonly Model.AppSetting _appSettingAccessor;
        private IMongoDatabase _iMongoDBDatabase;
        public SellerRepository(ILogger<SellerRepository> _logger, IOptions<Model.AppSetting> appSettingAccessor)
        {
            this.logger = _logger;
            _appSettingAccessor = appSettingAccessor.Value;
            var client = new MongoClient(_appSettingAccessor.DatabaseConnectionString);
            _iMongoDBDatabase = client.GetDatabase(_appSettingAccessor.DatabaseName);
        }

        public List<Model.Product> GetAllProduct()
        {
            logger.LogInformation("Method start" + nameof(GetAllProduct));
            return _iMongoDBDatabase.GetCollection<Model.Product>(Model.DBConstants.Product).Find(new BsonDocument()).ToList();
        }

        public Model.Product InsertProduct(Model.Product product)
        {
            logger.LogInformation("Method start" + nameof(InsertProduct));
            var _products = _iMongoDBDatabase.GetCollection<Model.Product>(Model.DBConstants.Product);
            Model.Product _product = new Model.Product()
            {
                ProductName= product.ProductName,
                ShortDescription = product.ShortDescription,
                DetailedDescription = product.DetailedDescription,
                Category = product.Category,
                StartingPrice = product.StartingPrice,
                BidEndDate = product.BidEndDate
            };
            _products.InsertOne(_product);
            logger.LogInformation("Method end" + nameof(InsertProduct));
            return _product;
        }

        public Model.Seller InsertSeller(Model.Seller seller)
        {
            logger.LogInformation("Method start" + nameof(InsertSeller));
            var _sellers = _iMongoDBDatabase.GetCollection<Model.Seller>(Model.DBConstants.Seller);
            Model.Seller _seller = new Model.Seller()
            {
                FirstName= seller.FirstName,
                LastName = seller.LastName,
                Address = seller.Address,
                City = seller.City,
                State = seller.State,
                Pin = seller.Pin,
                Phone = seller.Phone,
                Email = seller.Email
            };
            _sellers.InsertOne(_seller);
            logger.LogInformation("Method end" + nameof(InsertSeller));
            return _seller;
        }
        public string DeleteProduct(string productId)
        {
            logger.LogInformation("Method start" + nameof(DeleteProduct));
            var _filterProduct = Builders<Product>.Filter.Eq("_id", productId);
            var _products = _iMongoDBDatabase.GetCollection<Product>(Model.DBConstants.Product);
            _products.DeleteOne(_filterProduct);
            logger.LogInformation("Method end" + nameof(DeleteProduct));
            return "success";
        }
    }
}
